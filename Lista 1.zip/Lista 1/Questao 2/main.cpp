#include <iostream>
#include "Pessoa.h"

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}
void printPessoa(Pessoa pes){
    std::string nome = pes.getNome();
    std::string telefone = pes.getTelefone();
    int idade  = pes.getIdade();
    std::cout << "\nNome: " << nome << std::endl;
    std::cout << "Idade: " << idade << std::endl;
    std::cout << "Telefone: " << telefone << "\n" << std::endl; 
}
void exibeMenu(){
    std::cout << "\n~~~~MENU~~~~" << std::endl;
    std::cout << "1 - Set atributos" << std::endl;
    std::cout << "2 - Get atributos" << std::endl;
    std::cout << "3 - Finalizar\n" << std::endl;
    std::cout << "\nDigite a opcao desejada:";

}
void menuSet(){
    std::cout << "\n~~~~MENU SET~~~~" << std::endl;
    std::cout << "1 - Set Nome" << std::endl;
    std::cout << "2 - Set Idade" << std::endl;
    std::cout << "3 - Set Telefone\n" << std::endl;
    std::cout << "\nDigite a opcao desejada:";
}
void menuGet(){
    std::cout << "\n~~~~MENU GET~~~~" << std::endl;
    std::cout << "1 - Get Nome" << std::endl;
    std::cout << "2 - Get Idade" << std::endl;
    std::cout << "3 - Get Telefone\n" << std::endl;
    std::cout << "\nDigite a opcao desejada:";
}

int main(){
    Pessoa pessoa1 = Pessoa("Joao");
    Pessoa pessoa2 = Pessoa("Maria", 12, "4002-8922");
    bool loop = true;
    int menu, idade;
    std::string nome, telefone;

    limpaTela();
    std::cout << "Pessoa 1:";
    printPessoa(pessoa1);
    std::cout << "Pessoa 2:";
    printPessoa(pessoa2);
    std::cout << "Aperte ENTER pra usar set e get no Pessoa 1." << std::endl;
    getchar();

    while(loop){
        limpaTela();
        exibeMenu();
        std::cin >> menu;
        getchar();
        switch (menu){
            case 1:
                limpaTela();
                menuSet();
                std::cin >> menu;
                getchar();
                switch (menu){
                    case 1:
                        std::cout << "\nDigite o nome:";
                        getline(std::cin, nome);
                        pessoa1.setNome(nome);
                        break;
                    case 2:
                        std::cout << "\nDigite a idade:";
                        std::cin >> idade;
                        pessoa1.setIdade(idade);
                        break;
                    case 3:
                        std::cout << "\nDigite o telefone:";
                        getline(std::cin, telefone);
                        pessoa1.setTelefone(telefone);
                        break;
                    default:
                        limpaTela();
                        std::cout << "\nOpcao invalida, aperte ENTER pra voltar pro menu";
                        getchar();
                        break;
                }
                break;
            case 2:
                limpaTela();
                menuGet();
                std::cin >> menu;
                getchar();
                switch (menu){
                    case 1:
                        nome = pessoa1.getNome();
                        std::cout << "\nNome da pessoa 1: " << nome << std::endl; 
                        std::cout << "Aperte ENTER para prosseguir.";
                        getchar();
                        break;
                    case 2:
                        idade = pessoa1.getIdade();
                        std::cout << "\nIdade da pessoa 1: " << idade << std::endl; 
                        std::cout << "Aperte ENTER para prosseguir.";
                        getchar();
                        break;
                    case 3:
                        telefone = pessoa1.getTelefone();
                        std::cout << "\nTelefone da pessoa 1: " << telefone << std::endl; 
                        std::cout << "Aperte ENTER para prosseguir.";
                        getchar();
                        break;
                    default:
                        limpaTela();
                        std::cout << "\nOpcao invalida, aperte ENTER pra voltar pro menu";
                        getchar();
                        break;
                }
                break;
            case 3:
                loop = false;
                break;
            default:
                limpaTela();
                std::cout << "\nOpcao invalida, aperte ENTER pra voltar pro menu";
                getchar();
                break;
        }
    }

    limpaTela();
    std::cout << "Pessoa1 apos alteracoes:" << std::endl;
    printPessoa(pessoa1);
    std::cout << "Fim." << std::endl;

    return 0;
}