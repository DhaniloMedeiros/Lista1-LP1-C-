#pragma once
#include <iostream>

class Pessoa
{
public:
    void setNome(std::string n);
    void setIdade(int i);
    void setTelefone(std::string t);
    std::string getNome();
    int getIdade();
    std::string getTelefone();
    Pessoa(std::string n);
    Pessoa(std::string n, int i, std::string t);
private: 
    std::string nome;
    int idade;
    std::string telefone;
};
