#ifndef INVOICE_H_INCLUDED
#define INVOICE_H_INCLUDED

#include <iostream> 

class Invoice{
    public:
        //construtores
        Invoice();
        Invoice(int n, std::string d, int q, float p);
        //metodos
        int getNumero();
        std::string getDescricao();
        int getQuantidade();
        float getPreco();
        
        void setNumero(int num);
        void setDescricao(std::string desc);
        void setQuantidade(int quant);
        void setPreco(float prec);

        float getInvoiceAmount();
        void verificaQuantPreco();
    private:
        //atributos
        int numero;
        std::string descricao;
        int quantidade;
        float preco;
};
#endif /*INVOICE_H_INCLUDED*/