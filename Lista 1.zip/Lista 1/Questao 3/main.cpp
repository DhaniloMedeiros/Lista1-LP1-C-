#include "Invoice.h"
#include <iostream>

void limpa_tela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

void printInvoice(Invoice &Inv){
    int numero = Inv.getNumero();
    int quantidade = Inv.getQuantidade();
    std::string descricao = Inv.getDescricao();
    float preco = Inv.getPreco();
    std::cout << "\nNumero da fatura: " << numero << std::endl;
    std::cout << "Descricao: " << descricao << std::endl;
    std::cout << "Quantidade: " << quantidade << std::endl;
    std::cout << "Preco: R$ " << preco << "\n" <<std::endl;
}

void printInvoicePonteiro(Invoice *Inv){
    int numero = Inv->getNumero();
    int quantidade = Inv->getQuantidade();
    std::string descricao = Inv->getDescricao();
    float preco = Inv->getPreco();
    std::cout << "\nNumero da fatura: " << numero << std::endl;
    std::cout << "Descricao: " << descricao << std::endl;
    std::cout << "Quantidade: " << quantidade << std::endl;
    std::cout << "Preco: R$ " << preco << "\n" <<std::endl;
}


void menuSetGet(){
    puts("\n~~~~~Utilizar Set e Get~~~~~");
    puts("     1 - Set atributos");
    puts("     2 - Get atributos");
    puts("     3 - Continuar");

    std::cout << "Digite a opcao desejada:";
}

void menuSet(){
    puts("\n~~~~~MENU SET~~~~~");
    puts("   1 - Set numero");
    puts("   2 - Set descricao");
    puts("   3 - Set quantidade");
    puts("   4 - Set preco");

    std::cout << "Digite a opcao desejada:";
}

void menuGet(){
    puts("\n~~~~~MENU GET~~~~~");
    puts("   1 - Get numero");
    puts("   2 - Get descricao");
    puts("   3 - Get quantidade");
    puts("   4 - Get preco");

    std::cout << "Digite a opcao desejada:";
}

int main(){
    Invoice mouse = Invoice();
    Invoice circuitos = Invoice();
    Invoice *teclado = new Invoice();
    Invoice computador = Invoice(45002, "belissima maquina", 4, 6942.52);
    Invoice champoula = Invoice(45002, "Champoula DOURADA O_O",  -50, -50);
    
    int num,qnt;
    std::string dsc; //vars pro set.
    float prc;

    bool loop = true;
    int menu1, menu2; //variaveis pro while do menu

    std::cout << "Pressione ENTER para iniciar o programa." << std::endl;
    getchar();
    
    std::cout << "Testando o construtor com o Invoice Circuitos:" << std::endl;
    printInvoice(circuitos);

    std::cout << "Testando o construtor com o Invoice (ponteiro) Teclado:" << std::endl;
    printInvoicePonteiro(teclado);

    std::cout << "Testando o construtor com o Invoice Computador:" << std::endl;
    printInvoice(computador);

    std::cout << "Testando o construtor com o Invoice Champoula, com quantidade e preco negativo:" << std::endl;
    printInvoice(champoula);
    
    std::cout << "Defina os atributos da fatura do mouse. "<< std::endl;
    std::cout << "Numero da fatura:";
    std::cin >> num; 
    mouse.setNumero(num);
    getchar();
    std::cout << "Descricao da fatura:";
    getline(std::cin, dsc);
    mouse.setDescricao(dsc);
    std::cout << "Quantidade:";
    std::cin >> qnt;
    mouse.setQuantidade(qnt);
    std::cout << "Preco:";
    std::cin >> prc; 
    mouse.setPreco(prc);
    
    printInvoice(mouse);
    
    std::cout << "Agora utilizar os metodos set e get no mouse.\n" << "Pressione ENTER para prosseguir.";
    getchar();
    getchar();

    while(loop){
        limpa_tela();
        menuSetGet();
        std::cin >> menu1;
        
        if(menu1 == 1){
            menuSet();
            std::cin >> menu2;

            switch (menu2){
            case 1:
                std::cout <<"Set numero:";
                std::cin >> num;
                mouse.setNumero(num);
                break;
            case 2:
                std::cout <<"Set descricao:";
                getchar();
                getline(std::cin, dsc);
                mouse.setDescricao(dsc);
                break;
            case 3:
                std::cout <<"Set quantidade:";
                std::cin >> qnt;
                mouse.setQuantidade(qnt);
                break;
            case 4:
                std::cout <<"Set preco:";
                std::cin >> prc;
                mouse.setPreco(prc);
                break;            
            default:
                std::cout << "opcao invalida, prosseguindo o programa." << std::endl;
                loop = false;
                getchar();
                std::cout << "\nPressione ENTER.";
                getchar();
                break;
            }
        }else if(menu1 == 2){
            menuGet();
            std::cin >> menu2;

            switch (menu2){
            case 1:
                std::cout <<"Get numero:";
                num = mouse.getNumero();
                std::cout << num << std::endl;
                std::cout <<"\nAperte ENTER pra continuar.";
                getchar();
                getchar();
                break;
            case 2:
                std::cout <<"Get descricao:";
                dsc = mouse.getDescricao();
                std::cout << dsc << std::endl;
                std::cout <<"\nAperte ENTER pra continuar.";
                getchar();
                getchar();
                break;
            case 3:
                std::cout <<"Get quantidade:";
                qnt = mouse.getQuantidade();
                std::cout << qnt << std::endl;
                std::cout <<"\nAperte ENTER pra continuar.";
                getchar();
                getchar();
                break;
            case 4:
                std::cout <<"Get preco:";
                prc = mouse.getPreco();
                std::cout << prc << std::endl;
                std::cout <<"\nAperte ENTER pra continuar.";
                getchar();
                getchar();
                break;            
            default:
                std::cout << "opcao invalida, prosseguindo o programa." << std::endl;
                loop = false;
                getchar();
                std::cout << "\nPressione ENTER.";
                getchar();
                break;
            }
        }else{
            if(menu1 != 3)//pra simular um default, sem ter que por switch dentro de switch ^^
                std::cout << "Opcao invalida, prosseguindo o programa." << std::endl;
            loop = false;
        }
    }

    std::cout << "\nGet invoice amount do mouse: ";
    prc = mouse.getInvoiceAmount();
    std::cout << prc << std::endl;;
    
    std::cout << "Fim do programa." << std::endl;
    return 0;
}