#include "Invoice.h"
#include <iostream>

Invoice::Invoice(){
    numero = 1;
    descricao = "text";
    quantidade = 1;
    preco = 50.00;
}

Invoice::Invoice(int n, std::string d, int q, float p){
    numero = n;
    descricao = d;
    quantidade = q;
    preco = p;
    verificaQuantPreco();
}

int Invoice::getNumero(){
    return numero;
}

std::string Invoice::getDescricao(){
    return descricao;
}

int Invoice::getQuantidade(){
    return quantidade;  
} 

float Invoice::getPreco(){
    return preco;
}

void Invoice::setNumero(int num){
    numero = num;
}
void Invoice::setDescricao(std::string desc){
    descricao = desc;
}
void Invoice::setQuantidade(int quant){
    quantidade = quant;
    verificaQuantPreco();
}

void Invoice::setPreco(float prec){
    preco = prec;
    verificaQuantPreco();
}

float Invoice::getInvoiceAmount(){
    float fatura;
    fatura = quantidade * preco;

    return fatura;
}

void Invoice::verificaQuantPreco(){
    if(quantidade < 0)
        quantidade = 0;
    if(preco < 0.0)
        preco = 0.0;
}

