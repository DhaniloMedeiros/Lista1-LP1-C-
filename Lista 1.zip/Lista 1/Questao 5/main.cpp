#include "Horario.h"
#include <iostream>

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

void printHorario(Horario &hr){
    int hora = hr.getHora();
    int minuto = hr.getMinuto();
    int segundo = hr.getSegundo(); 
    std::cout << hora << ":" << minuto << ":" << segundo << std::endl;
}

void menuSetGet(){
    puts("\n~~~~~Utilizar Set e Get~~~~~");
    puts("     1 - Set atributos");
    puts("     2 - Get atributos");
    puts("     3 - Continuar");

   std::cout << "Digite a opcao desejada:";
}

void menuGet(){
    puts("\n~~~~~MENU GET~~~~~");
    puts("   1 - Get hora");
    puts("   2 - Get minuto");
    puts("   3 - Get segundo");

    std::cout << "Digite a opcao desejada:";
}

void menuSet(){
    puts("\n~~~~~MENU SET~~~~~");
    puts("   1 - Set hora");
    puts("   2 - Set minuto");
    puts("   3 - Set segundo");
    puts("   4 - Set horario");

    std::cout << "Digite a opcao desejada:";
}

int main(){
    Horario horario1 = Horario();
    Horario horario2 = Horario(22,22,22);
    Horario horario3 = Horario(12123,123123123,123123123);
    Horario horario4 = Horario(22,59,59);
    int loop = true;

    limpaTela();
    std::cout << "\nHorario1: ";
    printHorario(horario1);
    std::cout << "\nHorario2: ";
    printHorario(horario2);
    std::cout << "\nHorario3: ";
    printHorario(horario3);
    std::cout << "\nHorario4: ";
    printHorario(horario4);

    std::cout << "\nPressione Enter para usar set e get no Horario1.";
    getchar();

    while(loop){
        int menu;
        int set, get, hor, min, seg;
        limpaTela();
        menuSetGet();
        std::cin >> menu;
        getchar();
        switch (menu){
            case 1:
                limpaTela();
                menuSet();
                std::cin >> menu;
                getchar();
                switch (menu){
                    case 1:
                        std::cout << "\nDigite a nova hora:";
                        std::cin >> set;
                        horario1.setHora(set);
                        break;
                    case 2:
                        std::cout << "\nDigite o novo minuto:";
                        std::cin >> set;
                        horario1.setMinuto(set);
                        break;
                    case 3:
                        std::cout << "\nDigite o novo segundo:";
                        std::cin >> set;
                        horario1.setSegundo(set);
                        break;
                    case 4:
                        std::cout << "\nDigite a nova hora:";
                        std::cin >> hor;
                        std::cout << "\nDigite o novo minuto:";
                        std::cin >> min;
                        std::cout << "\nDigite o novo segundo:";
                        std::cin >> seg;
                        horario1.setHorario(hor, min, seg);
                        break;
                    default:
                        std::cout << "Opcao invalida aperte ENTER para voltar ao menu.";
                        getchar();
                        break;
                }
                break;
            case 2:
                limpaTela();
                menuGet();
                std::cin >> menu;
                getchar();
                switch (menu){
                    case 1:
                        get = horario1.getHora();
                        std::cout << "\nA hora eh = " << get << std::endl;
                        std::cout << "Aperte ENTER.";
                        getchar();
                        break;
                    case 2:
                        get = horario1.getMinuto();
                        std::cout << "\nO minuto eh = " << get << std::endl;
                        std::cout << "Aperte ENTER.";
                        getchar();
                        break;
                    case 3:
                        get = horario1.getSegundo();
                        std::cout << "\nO segundo eh =  " << get << std::endl;
                        std::cout << "Aperte ENTER.";
                        getchar();
                        break;
                    default:
                        std::cout << "Opcao invalida aperte ENTER para voltar ao menu.";
                        getchar();
                        break;
                }
                break;
            case 3  :
                loop = false;
                break;
            default:
                limpaTela();
                std::cout << "Opcao invalida aperte ENTER para voltar ao menu.";
                getchar();
                break;
        }
    }

    limpaTela();
    std::cout << "Horario1 alterado: ";
    printHorario(horario1);
    std::cout << "\nPressione ENTER para continuar.";
    getchar();
    loop = true;
    while(loop){
        int menu;
        limpaTela();
        puts("\nPressione 1 para adicionar um segundo ao horario4");
        puts("Pressione 2 para finalizar o programa");
        std::cin >> menu;
        getchar();
        switch (menu){
            case 1:
                limpaTela();
                std::cout << "Horario4 antes: ";
                printHorario(horario4);
                horario4.avancarHorario();
                std::cout << "Horario4 agora: " ;
                printHorario(horario4);
                std::cout << "\nPressione ENTER para continuar.";
                getchar();
                break;
            case 2:
                loop = false;
                break;
            default:
                limpaTela();
                std::cout << "Opcao invalida aperte ENTER para voltar ao menu.";
                getchar();
                break;
        }
    }
    limpaTela();
    std::cout << "~~~~~~~~~~~~~~~~~~~~~~" << std::endl;
    std::cout << "Finne del Programme." << std::endl;
    std::cout << "~~~~~~~~~~~~~~~~~~~~~~." << std::endl;
}