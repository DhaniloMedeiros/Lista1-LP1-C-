#include "Horario.h"
#include <iostream>

Horario::Horario(){
    hora = 00;
    minuto = 00;
    segundo = 00;
}
Horario::Horario(int h, int m, int s){
    hora = h;
    minuto = m;
    segundo = s;
    verificaHorario();
}
void Horario::setHorario(int h, int m, int s){
    hora = h;
    minuto = m;
    segundo = s;
    verificaHorario();
}
void Horario::setHora(int h){
    hora = h;
    verificaHorario();
}
void Horario::setMinuto(int m){
    minuto = m;
    verificaHorario();
}
void Horario::setSegundo(int s){
    segundo = s;
    verificaHorario();
}
int Horario::getHora(){
    return hora;
}
int Horario::getMinuto(){
    return minuto;
}
int Horario::getSegundo(){
    return segundo;
}
void Horario::verificaHorario(){
    if(hora < 0 || hora > 23)
        hora = minuto = segundo = 0;
    if(minuto < 0 || minuto > 59)
        hora = minuto = segundo = 0;
    if(segundo < 0 || segundo > 59)
        hora = minuto = segundo = 0;
}
bool Horario::avancarHorario(){
    bool loop = true;
    bool nextDay = false;
    segundo++;
    while(loop){
     bool verificar = true;
     if(segundo == 60){
        minuto++;
        segundo = 0;
        verificar = false;
     }
     if(minuto == 60){
        hora++;
        minuto = 0;
        verificar = false;
     }
     if(hora == 24){
        hora = minuto = segundo = 0;
        verificar = false;
        nextDay = true;
     }
     if(verificar)
        break;
    }
    return nextDay;
}