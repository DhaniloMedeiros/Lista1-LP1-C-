#include "ControleDePagamentos.h"
#include "Pagamento.h"
#include <iostream>

void menuSetGet(){
    puts("\n~~~~~Utilizar Set e Get~~~~~");
    puts("     1 - Set controle");
    puts("     2 - Get controle");
    puts("     3 - Continuar");

    std::cout << "Digite a opcao desejada:";
}
void menuSearch(){
    puts("\n~~~~~MENU FINAL~~~~~");
    puts("     1 - Ver se existe um funcionario.");
    puts("     2 - Finalizar o sofrimento.");

    std::cout << "Digite a opcao desejada:";
}
void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}
int main(){
    ControleDePagamentos Controle = ControleDePagamentos();
    Pagamento PagAux = Pagamento();
    bool loop = true;
    int menu1, index;
    double valorAux;
    std::string nomeAux;
    
    std::cout << "Pressione ENTER para comecar.";
    getchar();
    
    while(loop){
        limpaTela();
        menuSetGet();
        std::cin >> menu1;
        switch(menu1){
            case 1:
                std::cout << "\n~~~Setando controle de pagamentos~~~\n" << std::endl;
                std::cout << "Digite o indice do pagamento a ser alterado:";
                std::cin >> index;
                std::cout << "Digite o valor do pagamento:";
                std::cin >> valorAux;
                PagAux.setValorPagamento(valorAux); 
                std::cout << "Digite o nome do funcionario:";
                getchar();
                getline(std::cin, nomeAux);
                PagAux.setNomeFuncionario(nomeAux);
                Controle.setPagamentos(PagAux, index);
                break;
            case 2:
                std::cout << "\n~~~Get controle~~~\n" << std::endl;
                std::cout << "Digite o indice do pagamento que deseja ver:";
                std::cin >> index;
                valorAux = Controle.pagamentos[index].getValorPagamento();
                nomeAux = Controle.pagamentos[index].getNomeFuncionario();
                std::cout << "Valor do pagamento: R$" << valorAux << std::endl;
                std::cout << "Nome do funcionario: " <<nomeAux << std::endl;
                getchar();
                std::cout << "\nPressione ENTER para continuar.";
                getchar();
                break;
            case 3:
                loop = false;
                break;
            default:
                std::cout << "Opcao invalida prosseguindo o prog." << std::endl;
                getchar();
                std::cout << "\nPressione ENTER.";
                getchar();
                loop = false;
                break;
        }
    }
    
    limpaTela();
    getchar();
    valorAux = Controle.calculaTotalDePagamentos();
    std::cout << "O valor total dos pagamentos é: R$ " << valorAux << std::endl;
    std::cout << "\nPressione ENTER.";
    getchar();

    loop = true;
    
    while(loop){
        bool existe = false;
        limpaTela();
        menuSearch();
        std::cin >> menu1;
        switch(menu1){
            case 1:
                getchar();
                std::cout << "Digite o nome do funcionario:";
                getline(std::cin, nomeAux);
                existe =  Controle.existePagamentoParaFuncionario(nomeAux);
                if(existe == true)
                    std::cout << "Existe pagamento para este funcionario.\n" << std::endl;
                else
                    std::cout << "Nao existe pagamento para este funcionario.\n" << std::endl;
                std::cout << "Pressione ENTER para continuar." << std::endl;
                break;
            case 2:
                loop = false;
                break;
            default:
                std::cout << "Opcao invalida prosseguindo o prog." << std::endl;
                loop = false;
                getchar();
                std::cout << "\nPressione ENTER.";
                getchar();
                break;
        }
    }

    limpaTela();
    std::cout << "Fim do ROTEIRO.\n" << std::endl;
    std::cout << "⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⢠⢒⡉⠉⠲⢄⠄⠄⠄⠄⠄⠄⠄⠄" << std::endl;
    std::cout << "⠄⠄⠄⠄⠄⠄⠄⠠⠤⣀⠄⠄⠄⠄⢠⢧⡣⢂⠄⠄⠄⠳⣄⣀⣀⡠⠄⠄⠄" << std::endl;
    std::cout << "⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠙⠢⣄⢠⠏⢀⡷⢁⠄⠄⠄⠄⠘⣄⠄⠄⠄⠄⠄" << std::endl;
    std::cout << "⠄⠄⠄⠄⠄⠄⢀⣀⠤⠤⠔⠒⣺⢾⠚⢉⡘⠤⠷⢤⠔⠄⠄⠘⡍⠓⢤⠄⠄" << std::endl;
    std::cout << "⠄⠄⠄⠄⠄⠈⠁⠄⠄⣠⠖⠋⠰⠁⠄⠄⠈⡳⡀⠘⡄⠄⠄⠄⠹⡄⠄⢳⠄" << std::endl;
    std::cout << "⢀⠤⢤⠖⠒⠢⣀⣴⢫⠂⠄⠄⠄⠄⠄⠄⣾⣿⣷⠄⢳⠄⠄⠄⠄⢳⠄⢘⡇" << std::endl;
    std::cout << "⡔⡩⠽⣀⣰⠔⢹⣄⣿⠄⢀⣤⣄⠄⠄⠄⠘⠿⠏⠄⠈⡇⠄⠄⠄⠘⡆⣸⠁" << std::endl;
    std::cout << "⢫⠔⠂⢺⠒⠂⠄⠄⡼⢆⠘⢿⣿⢦⠒⠄⠄⠄⢈⠖⠄⣹⠄⠄⠄⠄⣿⠇⠄" << std::endl;
    std::cout << "⠘⢆⡈⢉⣀⣤⡀⡜⠁⠄⠑⠄⠁⠄⠉⢀⣠⣴⣿⡄⠄⢯⣦⣤⣴⣾⣿⡆⠄" << std::endl;
    std::cout << "⠄⠄⠈⠉⠄⠄⠉⢇⠄⠄⠄⠄⠈⠉⠛⢿⣿⣿⣿⡧⠄⢸⣿⣿⣿⣿⣿⡇⠄" << std::endl;
    std::cout << "⠄⠄⠄⠄⠄⠄⠄⠈⠳⢄⡀⠄⠄⠄⠄⠄⠈⠉⢉⣡⣴⣿⣿⣿⣿⣿⣿⡃⠄" << std::endl;
    std::cout << "⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠈⠙⠒⠒⠶⣶⡾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠄" << std::endl;
    std::cout << "⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣀⣀⣀⣀⣎⣶⣿⣿⠛⢹⣿⣿⣿⣿⣿⣿⣿⡄" << std::endl;
    std::cout << "⠄⠄⠄⠄⠄⠄⠄⠄⠄⡴⠋⠁⠄⢹⣿⣷⣟⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⡇" << std::endl;
    std::cout << "⠄⠄⠄⠄⠄⠄⠄⠄⢸⡇⠄⠄⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿" << std::endl;
    std::cout << "⠄⠄⠄⠄⠄⠄⣠⣴⣶⣧⠄⠄⠄⢀⣘⣿⣮⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃" << std::endl;
    std::cout << "⠄⠄⠄⠄⠄⣼⣿⣿⣿⡣⡑⢄⣀⠄⢀⡨⢻⠛⣴⣭ " << std::endl;
   
    return 0;
}
