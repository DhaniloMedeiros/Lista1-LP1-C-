#ifndef CONTROLE_DE_PAGAMENTOS_H_INCLUDED
#define CONTROLE_DE_PAGAMENTOS_H_INCLUDED

#include "Pagamento.h"
#include <iostream>

#define TAM 20

class ControleDePagamentos
{
    public:
        //atributos
        Pagamento pagamentos[TAM];
        //construtor 
        ControleDePagamentos();
        //metodos
        void setPagamentos(Pagamento pag, int i);
        double calculaTotalDePagamentos();
        bool existePagamentoParaFuncionario(std::string str); 
};


#endif//PAGAMENTO_H_INCLUDED