#include "ControleDePagamentos.h"
#include "Pagamento.h"
#include <iostream>
#include <string>

ControleDePagamentos::ControleDePagamentos(){
    int i;
    for(i = 0; i < TAM; i++){
        pagamentos[i].valorPagamento = 0;
        pagamentos[i].nomeFuncionario = "NULL";        
    }
}
void ControleDePagamentos::setPagamentos(Pagamento pag, int i){
    pagamentos[i].valorPagamento = pag.valorPagamento;
    pagamentos[i].nomeFuncionario = pag.nomeFuncionario;
}
double ControleDePagamentos::calculaTotalDePagamentos(){
    int i;
    double valorTotal = 0;
    for(i = 0; i < TAM; i++){
        valorTotal += pagamentos[i].valorPagamento;
    }
    return valorTotal;
}
bool ControleDePagamentos::existePagamentoParaFuncionario(std::string str){
    int i;
    bool existe = false;
    for(i = 0; i < TAM; i++){
        if(pagamentos[i].nomeFuncionario.find(str) != std::string::npos){//achou
            existe = true;
            break;
        }
    }
    return existe;
}