#include "Data.h"
#include <iostream>


void printData(Data &dt){
    int dia = dt.getDia();
    int mes = dt.getMes();
    int ano = dt.getAno(); 
    std::cout << dia << "/" << mes << "/" << ano << std::endl;
}
void printDataExtenso(Data &dt){
    int dia = dt.getDia();
    std::string mes = dt.getMesExtenso();
    int ano = dt.getAno(); 
    std::cout << dia << " de " << mes << " de " << ano << std::endl;
}

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

void menuSetGet(){
    puts("\n~~~~~Utilizar Set e Get~~~~~");
    puts("     1 - Set atributos");
    puts("     2 - Get atributos");
    puts("     3 - Continuar");

   std::cout << "Digite a opcao desejada:";
}

void menuGet(){
    puts("\n~~~~~MENU GET~~~~~");
    puts("   1 - Get dia");
    puts("   2 - Get mes");
    puts("   3 - Get ano");

    std::cout << "Digite a opcao desejada:";
}

void menuSet(){
    puts("\n~~~~~MENU SET~~~~~");
    puts("   1 - Set dia");
    puts("   2 - Set mes");
    puts("   3 - Set ano");

    std::cout << "Digite a opcao desejada:";
}

int main(){
    /*Data aniversario = Data();
    Data hoje = Data(13, 11, 2019);
    Data *ontem = new Data(12, 11, 2019);
    Data data_errada = Data(123, 123, -2); ((Maneiras de declarar objeto.))
    Data data54;
    Data data_teste = Data(1,1, 2001);
    */
    Data data1 = Data(10, 12, 2019);
    Data data2 = Data(29, 02, 2013);//data inválida;
    Data data3 = Data(29, 02, 2000);//ano bissexto;
    int i, menu;
    bool loopMenu = true;
    limpaTela();
    std::cout << "\nData 1: " << std::endl;
    printData(data1);
    std::cout << "\nData 2: " << std::endl;
    printData(data2);
    std::cout << "\nData 3: " << std::endl;
    printData(data3);

    std::cout << "\nPressione ENTER para usar set e get na data 1." << std::endl;
    getchar();
    
    limpaTela();
    while(loopMenu){
        int opcao;
        int set, get;
        limpaTela();
        menuSetGet();
        std::cin >> menu;
        getchar();
        switch(menu){
            case 1:
                limpaTela();
                std::cout << "Em caso de data invalida, esta sera redefinida automaticamente." << std::endl;
                menuSet();
                std::cin >> opcao;
                getchar();
                switch(opcao){
                    case 1:
                        std::cout << "Alterar dia:";
                        std::cin >> set; 
                        data1.setDia(set);
                        break;
                    case 2:
                        std::cout << "Alterar mes:";
                        std::cin >> set; 
                        data1.setMes(set);
                        break;
                    case 3:
                        std::cout << "Alterar ano:";
                        std::cin >> set; 
                        data1.setAno(set);
                        break;
                    default:
                        std::cout << "Opcao invalida, prosseguindo o programa.";
                        loopMenu = false;
                        getchar();
                        std::cout << "\nPressione ENTER.";
                        getchar();
                        break;
                }
                break;
            case 2:
                limpaTela();
                menuGet();
                std::cin >> opcao;
                getchar();
                switch(opcao){
                    case 1:
                        get = data1.getDia();
                        std::cout << "Dia: " << get << std::endl;
                        std::cout << "Pressione ENTER" << std::endl;
                        getchar();
                        break;
                    case 2:
                        get = data1.getMes();
                        std::cout << "Mes: " << get << std::endl;
                        std::cout << "Pressione ENTER" << std::endl;
                        getchar();
                        break;
                    case 3:
                        get = data1.getAno();
                        std::cout << "Ano: " << get << std::endl;
                        std::cout << "Pressione ENTER" << std::endl;
                        getchar();
                        break;
                    default:
                        std::cout << "Opcao invalida, voltando ao menu.";
                        std::cout << "\nPressione ENTER.";
                        getchar();
                        break;
                }
                break;
            case 3:
                loopMenu = false;
                break;
            default:
                std::cout << "Opcao invalida, voltando ao menu.";
                std::cout << "\nPressione ENTER.";
                getchar();
                break;
        }
    }

    limpaTela();
    std::cout << "Datas por extenso:" << std::endl;
    std::cout << "\nData 1: " << std::endl;
    printDataExtenso(data1);
    std::cout << "\nData 2: " << std::endl;
    printDataExtenso(data2);
    std::cout << "\nData 3: " << std::endl;
    printDataExtenso(data3); 
    std::cout << "\nPressione ENTER para continuar.";
    getchar();

    limpaTela();
    if(data1.isBissexto())
        std::cout << "Data 1 eh bissexto." << std::endl;
    else 
        std::cout << "Data 1 nao eh bissexto." << std::endl;
    if(data2.isBissexto())
        std::cout << "Data 2 eh bissexto." << std::endl;
    else 
        std::cout << "Data 2 nao eh bissexto." << std::endl;
    if(data3.isBissexto())
        std::cout << "Data 3 eh bissexto." << std::endl;
    else 
        std::cout << "Data 3 nao eh bissexto." << std::endl;
    
    std::cout << "\nPressione ENTER para continuar.";
    getchar();
    
    limpaTela();
    if(data1.compara(data2) == 1)
        std::cout << "A data1 eh maior que a data2." << std::endl;
    else if(data1.compara(data2) == 0)
        std::cout << "A data1 eh igual a data2." << std::endl;
    else
        std::cout << "A data1 eh menor que a data2." << std::endl;
    //
    if(data1.compara(data3) == 1)
        std::cout << "A data1 eh maior que a data3." << std::endl;
    else if(data1.compara(data3) == 0)
        std::cout << "A data1 eh igual a data3." << std::endl;
    else
        std::cout << "A data1 eh menor que a data3." << std::endl;
    //
    if(data2.compara(data3) == 1)
        std::cout << "A data2 eh maior que a data3." << std::endl;
    else if(data2.compara(data3) == 0)
        std::cout << "A data2 eh igual a data3." << std::endl;
    else
        std::cout << "A data2 eh menor que a data3." << std::endl;

    std::cout << "\nO programa chegou ao fim." << std::endl;

    return 0;
} 