#include "Voo.h"
#include <iostream>

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

void printHorario(Horario &hr){
    int hora = hr.getHora();
    int minuto = hr.getMinuto();
    int segundo = hr.getSegundo(); 
    std::cout << hora << ":" << minuto << ":" << segundo << std::endl;
}

void printData(Data &dt){
    int dia = dt.getDia();
    int mes = dt.getMes();
    int ano = dt.getAno(); 
    std::cout << dia << "/" << mes << "/" << ano << std::endl;
}

void printVoo(Voo &flight){
    Horario horario = flight.getHorario();
    Data data = flight.getData();
    std::cout << "Numero do voo: " << flight.getNumVoo() << std::endl;
    std::cout << "Horario do voo: ";
    printHorario(horario);
    std::cout << "Data do voo: ";
    printData(data);
}

void menuGet(){
    puts("\n~~~~~MENU GET~~~~~");
    puts("   1 - Get numero");
    puts("   2 - Get data");
    puts("   3 - Get horario");

    std::cout << "Digite a opcao desejada:";
}

void menuVoo(){
    puts("\n~~~~~MENU VOO~~~~~");
    puts("   1 - Menu get");
    puts("   2 - Verificar assento");
    puts("   3 - Ocupar assento");
    puts("   4 - Proxima cadeira livre");
    puts("   5 - Numero de vagas");
    puts("   6 - Finalizar o programa");

    std::cout << "Digite a opcao desejada:";
}

int main(){
    Voo voo1 = Voo(123, 12, 12, 2002, 14, 30, 0);
    Voo voo2 = Voo(321, 99, 99, 2001, 99, 99, 99);
    int loop;

    limpaTela();
    std::cout << "Voo 1:" << std::endl;
    printVoo(voo1);
    std::cout << "Voo 2:" << std::endl;
    printVoo(voo2);

    std::cout << "\nAperte ENTER pra usa os metodos no voo1.";
    getchar();

    while(loop){
        int menu, assento;
        Horario hor = voo1.getHorario();
        Data dat = voo1.getData();

        limpaTela();
        menuVoo();
        std::cin >> menu;
        getchar();
        switch (menu){
            case 1:
                limpaTela();
                menuGet();
                std::cin >> menu;
                getchar();
                switch (menu)
                {
                    case 1:
                        std::cout << "O numero do voo eh: " << voo1.getNumVoo() << std::endl;
                        std::cout << "Aperte ENTER.";
                        getchar();
                        break;
                    case 2:
                        std::cout << "A data do voo eh: ";
                        printData(dat);
                        std::cout << "Aperte ENTER.";
                        getchar();
                        break;
                    case 3:
                        std::cout << "O horario do voo eh: ";
                        printHorario(hor);
                        std::cout << "Aperte ENTER.";
                        getchar();
                        break;
                    default:
                        std::cout << "Opcao invalida aperte ENTER pra voltar ao menu.";
                        getchar();
                        break;
                    }
                break;
            case 2:
                limpaTela();
                std::cout << "Digite o numero do assento de 1 a 100 que deseja verificar:";
                std::cin >> assento;
                getchar();
                if(voo1.verifica(assento))
                    std::cout << "O assento esta ocupado." << std::endl;
                else    
                    std::cout << "O assento esta livre." << std::endl;
                std::cout << "Aperte ENTER.";
                getchar();
                break;
            case 3:
                limpaTela();
                std::cout << "Digite o numero do assento de 1 a 100 que deseja ocupar:";
                std::cin >> assento;
                getchar();
                if(voo1.ocupa(assento))
                    std::cout << "O assento foi ocupado com sucesso!" << std::endl;
                else    
                    std::cout << "O assento ja tem dono." << std::endl;
                std::cout << "Aperte ENTER.";
                getchar();
                break;
            case 4:
                limpaTela();
                std::cout << "A proxima cadeira livre eh a: " << voo1.proximoLivre() << std::endl;
                std::cout << "Aperte ENTER.";
                getchar();
                break;
            case 5:
                limpaTela();
                std::cout << "O numero de vagas eh: " << voo1.vagas() << std::endl;
                std::cout << "Aperte ENTER.";
                getchar();
                break;
            case 6:
                limpaTela();
                loop = false;
                break;
            default:
                limpaTela();
                std::cout << "Opcao invalida aperte ENTER pra voltar ao menu.";
                getchar();
                break;
        }
    }
    std::cout << "Fim." << std::endl;

}