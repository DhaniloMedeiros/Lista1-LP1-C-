#ifndef DATA_H_INCLUDED
#define DATA_H_INCLUDED
#include <iostream>
class Data  
{
public:
    //construtores
    Data();
    Data(int d, int m, int a);
    //metodos
    int getDia();
    int getMes();
    int getAno();
    void setDia(int d);
    void setMes(int m);
    void setAno(int a);

    int compara(Data dtcomp);
    void verificarData();
    std::string getMesExtenso();
    bool isBissexto();

private:
    //atributos
    int dia, mes, ano;
};

#endif //DATA_H_INCLUDED