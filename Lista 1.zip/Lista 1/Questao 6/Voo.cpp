#include "Voo.h"

Voo::Voo(int n, int d, int m, int a, int hr, int min, int sec){
    int i;
    for(i = 0; i < TAM; i++)
        lugares[i] = false;
    numero = n;
    data.setDia(d);
    data.setMes(m);
    data.setAno(a);
    horario.setHorario(hr, min, sec);
}
int Voo::proximoLivre(){
    int i;
    for(i = 0; i < TAM; i++){
        if(!lugares[i])
            break;
    }
    return (i+1);
}
bool Voo::verifica(int i){
    if(lugares[i-1])
        return true;
    else
        return false;
}
bool Voo::ocupa(int i){
    if(lugares[i-1])
        return false;
    else{
        lugares[i-1] = true;
        return true;
    }
    
}
int Voo::vagas(){
    int vagas = 0;
    int i;
    for(i = 0; i < TAM; i++){
        if(!lugares[i])
            vagas++;
    }
    return vagas;
}
int Voo::getNumVoo(){
    return numero;
}
Data Voo::getData(){
    return data;
}
Horario Voo::getHorario(){
    return horario;
}