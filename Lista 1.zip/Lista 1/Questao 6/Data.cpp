#include "Data.h"
#include <iostream>

Data::Data(){
    dia = 01;
    mes = 01;
    ano = 2001; 
}
Data::Data(int d, int m, int a){
    dia = d;
    mes = m;
    ano = a;
    Data::verificarData();
}
int Data::getDia(){
    return dia;
}
int Data::getMes(){
    return mes;
}
int Data::getAno(){
    return ano;
}
void Data::setDia(int d){
    dia = d;  
    Data::verificarData(); 
}
void Data::setMes(int m){
    mes = m;
    Data::verificarData(); 
}
void Data::setAno(int a){
    ano = a;
    Data::verificarData(); 
}
int Data::compara(Data dtcomp){
    int dia1 = getDia();
    int mes1 = getMes();
    int ano1 = getAno();
    int dia2 = dtcomp.getDia();
    int mes2 = dtcomp.getMes();
    int ano2 = dtcomp.getAno();
    
    if(ano1 > ano2)
        return 1;
    else if(ano1 < ano2)
        return -1;
    else{
        if(mes1 > mes2)
            return 1;
        else if(mes1 < mes2)
            return -1;
        else{
            if(dia1 > dia2)
                return 1;
            else if(dia1 < dia2)
                return -1;
            else
                return 0;
        }
    }
}
void Data::verificarData(){
    int verificar = 0;
    
    //ajusta ano
    if(ano < 1){
        ano = 2001;
        mes = 01;
        dia = 01;
        verificar = 1;
    }
    //ajusta mes
    else if(mes > 12 || mes < 1){
        ano = 2001;
        mes = 01;
        dia = 01;
        verificar = 1;
    }

    //ajusta dia
    if(mes == 1 || mes == 3|| mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12){
        //meses de 31 dias  
        if(dia > 31 || dia < 1){
            ano = 2001;
            mes = 01;
            dia = 01;
            verificar = 1;
        }
    }
    else if(mes == 4 || mes == 6 || mes == 9 || mes == 11){
        //meses de 30 dias
        if(dia > 30 || dia < 1){
            ano = 2001;
            mes = 01;
            dia = 01;
            verificar = 1;
        }
    }
    
    else if(mes == 2){
        //fevereiro
        if(isBissexto()){
            if(dia > 29 || dia < 1){
                ano = 2001;
                mes = 01;
                dia = 01;
                verificar = 1;
            }
        }else{
            if(dia > 28 || dia < 1){
                ano = 2001;
                mes = 01;
                dia = 01;
                verificar = 1;
            }
        }
    }
    return;
}
std::string Data::getMesExtenso(){
    int mes = getMes();
    switch (mes){
    case 1:
        return "Janeiro";
        break;
    case 2:
        return "Fevereiro";
        break;
    case 3:
        return "Marco";
        break;
    case 4:
        return "Abril";
        break;
    case 5:
        return "Maio";
        break;
    case 6:
        return "Junho";
        break;
    case 7:
        return "Julho";
        break;
    case 8:
        return "Agosto";
        break;
    case 9:
        return "Setembro";
        break;
    case 10:
        return "Outubro";
        break;
    case 11:
        return "Novembro";
        break;
    case 12:
        return "Dezembro";
        break;
    }
}
bool Data::isBissexto(){
    int ano = getAno();
    if(ano % 400 == 0)
        return true;
    else if(ano % 4 == 0 && ano % 100 != 0)
        return true;
    else
        return false;
}