#pragma once

#include "Data.h"
#include "Horario.h"
#define TAM 100

class Voo
{
private:
    bool lugares[TAM];   
    int numero;
    Data data;
    Horario horario;    

public:
    Voo(int n, int d, int m, int a, int hr, int min, int sec);
    int proximoLivre();
    bool verifica(int i);
    bool ocupa(int i);
    int vagas();
    int getNumVoo();
    Data getData();
    Horario getHorario();
};

